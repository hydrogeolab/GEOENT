%%
% *%%       GEOENT: Geological Entropy toolbox     *
%
%   ,ad8888ba,   88888888888    ,ad8888ba,    88888888888  888b      88  888888888888  
%  d8"'    `"8b  88            d8"'    `"8b   88           8888b     88       88       
% d8'            88           d8'        `8b  88           88 `8b    88       88       
% 88             88aaaaa      88          88  88aaaaa      88  `8b   88       88       
% 88      88888  88"""""      88          88  88"""""      88   `8b  88       88       
% Y8,        88  88           Y8,        ,8P  88           88    `8b 88       88       
%  Y8a.    .a88  88            Y8a.    .a8P   88           88     `8888       88       
%   `"Y88888P"   88888888888    `"Y8888Y"'    88888888888  88      `888       88         
%                                                      
%                                                      
% Purpose:      Calculate anisotropic entrogram of a 2-D or 3-D grid and
%               compute relative entropy and entropic scale
% Author:       Daniele Pedretti, Marco Bianchi
% Version:      1.0
% Last update:  14 February 2022
% License:      The code is distributed under CC BY-NC-ND 4.0 International Public License
%               (Creative Commons Attribution-NonCommercial-NoDerivatives 4.0)
%               https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode)
%               (The code is provided without any warranty and for non-commercial use only.

%               You can freely use the code for research purposes, provided that the authors are
%               acknowledged. 
% References:
%              1. Bianchi, M., and Pedretti, D. (2017). Geological entropy and solute transport
%               in heterogeneous porous media: Water Resources Research 53, 4691�4708.
%              2. Bianchi, M., and Pedretti, D. (2018). An Entrogram-Based Approach to Describe
%               Spatial Heterogeneity With Applications to Solute Transport in Porous Media.
%               Water Resources Research 54, 4432�4448.
%              3. Pedretti, D., and Bianchi, M. (2022). GEOENT:  An open-source MATLAB� / GNU
%               Octave Toolbox for calculating geological entropy. Geosciences (pending more information)
%
%               For any comment and feedback, or to discuss a Licence agreement for commercial use,
%               please contact us: Daniele Pedretti (daniele.pedretti@unimi.it), Marco Bianchi (marcob@bgs.ac.uk), 
%
%               Thank you for using GEOENT!
%-------------------------------------------------------------------------------
%

%% Instructions:
%    Input:
%           - BLOCK 1: The user provides the dataset. As an example, we
%                      import a RAW image (3-D dataset).
%                      The size of the raster is specified in this block.
%           - BLOCK 2: The number of categories is specified.
%           - BLOCK 3: The parameters controlling sectors for entrogram calculations are specified.
%           - BLOCK 4: Set the size of the bandwidth
%           - BLOCK 5: specify the number of directions (NDIR) and angles of rotation
%                   (one value for each NDIR). Rotation is first about  the vertical z axis (i.e. strike)
%                    and then about the y axis (i.e. dip)
%   Calculation
%           - BLOCK 6: the algorithm for the calculation of the entrogram is
%           launched, for each direction. The number of processes lags
%           appears in the "Command Window"
%           
%           GEOENT calculates
%           - the global Shannon entropy of this dataset (H0)
%           - the relative entropy (HR)
%           - the entrogram for each direction
%           - the corresponding entropy scale (HS)
%
%   Output: 
%           - BLOCK 7: 
%           -the results are saved in a MATLAB .mat file
%           - ASCII output files containing the entrograms in the different
%           directions are created
%           - Figures of the global-entropy-normalized and not-normalized
%           entrograms are generated as saved as .fig files.
%
clear all; close all; fclose all; clc;

%% --- BLOCK 1 : input data

% example: calculate GEOENT on a RAW image (3-D raster)

inputfilename='sim_001.vtk';
NJ=280;            % number of cells in X direction
NI=70;            % number of cells in Y direction
NK=58;            % number of cells in Z direction

vtk_file=import_vtk(inputfilename);
field_3D=reshape(vtk_file,[NJ,NI,NK]); % Matlab 3D arrays: Y,X,Z
field_3D=flipud(rot90(field_3D));

dx = 1.;            % size/spacing of the cells in X direction
dy = 1.;            % size/spacing of the cells in Y direction
dz = 1.;            % size/spacing of the cells in Z direction

input_gslib=vtk2gslib(field_3D,NI,NJ,NK);

%% --- BLOCK 2 : Number of categories
Ncat=2;                 % number of categories (min 2)

%% --- BLOCK 3: Number of repetitions and entrogram lags
NMC=500;                % number of repetitions to compute ensemble average of entrograms (min 2 - suggested 500)
loglag=false;           % if active: lags are computed logarithmically
lagsteplogspace=20;     % if loglag=false: steps of the logarithmically spaced lags
lagstep=1;              % if loglag=false: frequency of the linearly spaced lags

%% --- BLOCK 4 : Size of the searching box ("bandwidth")
bandwidth_X=58;         % max size (number of cells) of searching box along X (J) direction
bandwidth_Y=1;          % max size (number of cells) of searching box along Y (I) direction
bandwidth_Z=1;          % max size (number of cells) of searching box along Z (K) direction (set 1 for 2D datasets)

%% --- BLOCK 5 : Directional entrogram properties
NUMDIR = 3;          % number of directions (max 3)
alpha = [0. 90. 0.]; % angle of rotation of the searching box about the z axis ("strike")
beta = [0. 0. 90.];  % angle of rotation of the searching box about the y axis ("dip")

nHs_flag=1;         % if active: normalized entropic scale is reported

%% --- BLOCK 6: Start calculation
xyz_ind_gslib=discretize(input_gslib,Ncat);

% Calculate lags
if loglag
    lagsteplog=logspace(0,log10((max([NJ,NI,NK])-1)/2),lagsteplogspace);
    Lagsin=unique(floor(lagsteplog));
else
    Lagsin=1:lagstep:(max([NJ,NI,NK])-1);
end

% loop over the directions (NDIR)
for nd =1:NUMDIR
    textdisp= ['strike = ',num2str(alpha(nd)),';  dip = ',num2str(beta(nd))];
    disp(textdisp)
    [H0,HL_d,dist_d]=entrogram_v14(xyz_ind_gslib,Lagsin,bandwidth_X,bandwidth_Y,bandwidth_Z,...
        alpha(nd),beta(nd),NI,NJ,NK,dx,dy,dz,Ncat,NMC);
    
    % Store entrograms and corresponding distances
    eval(strcat('HL_d',num2str(nd),' = HL_d;'));
    eval(strcat('H0_d',num2str(nd),' = H0;'));
    eval(strcat('dist_d',num2str(nd),' = dist_d;'));
end

%% --- BLOCK7: Output


col = ['r';'b';'g']; %colours for plotting entrograms
mark= ['o';'s';'x'];

figure('color','w')

subplot(2,1,1) % Plot the H0-normalised entrogram

hold on

for nd =1:NUMDIR
    eval(['HL = ',strcat('HL_d',num2str(nd)),';']);
    eval(['H0 = ',strcat('H0_d',num2str(nd)),';']);
    eval(['dist = ',strcat('dist_d',num2str(nd)),';']);
    
    % save calculated entrograms on external ASCII files
    ffile = strcat('HL_d',num2str(nd),'.txt');
    eval(strcat('datawrite = [Lagsin(1:length(dist))''',',dist',',HL',',HL/H0];'))
    save('-ascii',ffile,'datawrite');
        
    plot1=plot([0;dist],[0;HL/H0],'Marker',mark(nd),'linewidth',1.,'markersize',5,'color',col(nd));

    xlabel('Lags');
    ylabel('H_R=H_L/H_0');
    h = legend('show');
    set(h,'location','southeast','fontsize',10, 'fontname', 'Arial')
    set(gca, 'fontsize',10,'linewidth',1,'FontName','Arial','box', 'off',...
        'tickdir','out','ticklength',[0.009,0.009]);
    
    Hscale(nd) = trapz([0;dist],[1;1-HL/H0]);       % Calculate entropic scale
    normHscale(nd)=Hscale(nd)/dist(end);            % Calculate normalized entropic scale
    
    if nHs_flag
        name2plot=horzcat('dir ',num2str(nd),' - nH_{S}= ',num2str(normHscale(nd),'%3.2f'));
    else
        name2plot=horzcat('dir ',num2str(nd),' - H_{S}= ',num2str(Hscale(nd),'%3.2f'));
    end
    
    set(plot1,'DisplayName',name2plot);
    ylim([0.0 1.1])

    
end

%set the dataset name and report relative and global entropy
tit=title(strcat('H_{R0} =',num2str(HL(1)/H0,'%3.2f'),' - H_0=',num2str(H0,'%3.2f')));
set(tit,'FontSize',12);

subplot(2,1,2) % Plot the not-normalised entrogram
hold on
for nd =1:NUMDIR
    eval([ 'HL= ',strcat('HL_d',num2str(nd)),';']);
    eval([ 'dist= ',strcat('dist_d',num2str(nd)),';']);

    plot1=plot([0;dist],[0;HL],'Marker',mark(nd),'linewidth',1.,'markersize',5,'color',col(nd));
    xlabel('Lags (Distance)');
    ylabel('H_L');
    
    name2plot=horzcat('H_0(dir ',num2str(nd),')\rightarrow',num2str(mean(HL(end-3:end)),'%3.2f'));
    set(plot1,'DisplayName',name2plot);
    h = legend('show');
    set(h,'location','southeast','fontsize',10, 'fontname', 'Arial')
    set(gca, "fontsize",10,'linewidth',1,'FontName','Arial','box', 'off',...
        'tickdir','out','ticklength',[0.009,0.009]);
end

saveas(gcf,'entrograms.fig');
% exportgraphics(gcf,'entrograms.png'); % uncomment to save as PNG file.
% save('geoentropy.mat','-v7.3'); % uncomment to store results in .mat file.



